// This is a pre-build script that tries to fix file structure issues on Render
const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

console.log('=== RENDER PRE-BUILD FIX ===');
console.log(`Current working directory: ${process.cwd()}`);

// Check if package.json exists in current directory
const packageJsonPath = path.join(process.cwd(), 'package.json');
if (!fs.existsSync(packageJsonPath)) {
  console.log('package.json not found in current directory, searching for it...');
  
  // Try to find where the code might be
  const possibleDirs = [
    '/opt/render/project/src',
    '/opt/render/project',
    '/opt/render',
    '/app',
    '/src'
  ];
  
  let sourceDir = null;
  for (const dir of possibleDirs) {
    if (fs.existsSync(dir) && fs.existsSync(path.join(dir, 'package.json'))) {
      sourceDir = dir;
      console.log(`Found package.json in ${sourceDir}`);
      break;
    }
  }
  
  if (sourceDir) {
    // Copy all files from source directory to current directory
    console.log(`Copying all files from ${sourceDir} to ${process.cwd()}`);
    try {
      fs.readdirSync(sourceDir).forEach(file => {
        if (file !== 'node_modules' && file !== '.git') {
          const sourcePath = path.join(sourceDir, file);
          const destPath = path.join(process.cwd(), file);
          
          if (fs.statSync(sourcePath).isDirectory()) {
            // Copy directory recursively
            child_process.execSync(`cp -r "${sourcePath}" "${destPath}"`);
          } else {
            // Copy file
            fs.copyFileSync(sourcePath, destPath);
          }
          console.log(`Copied ${file}`);
        }
      });
      console.log('Files copied successfully');
    } catch (error) {
      console.error(`Error copying files: ${error.message}`);
    }
  } else {
    console.error('Could not find package.json in any expected location');
  }
}

// Check if package.json exists now
if (fs.existsSync(packageJsonPath)) {
  console.log('package.json now exists in current directory');
  try {
    const packageJson = require(packageJsonPath);
    console.log(`Package name: ${packageJson.name}`);
  } catch (e) {
    console.error(`Error parsing package.json: ${e.message}`);
  }
} else {
  console.error('package.json still not found after attempted fix');
}