import { MarketInsight } from "@shared/schema";
import { Link } from "wouter";

interface InsightCardProps {
  insight: MarketInsight;
}

const InsightCard = ({ insight }: InsightCardProps) => {
  // Define badge style based on importance
  const getBadgeStyle = (importance: string) => {
    switch (importance) {
      case 'important':
        return 'bg-status-warning bg-opacity-10 text-status-warning';
      case 'urgent':
        return 'bg-status-error bg-opacity-10 text-status-error';
      default:
        return 'bg-status-info bg-opacity-10 text-status-info';
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border">
      <div className="flex items-start justify-between mb-3">
        <h4 className="font-heading font-semibold">{insight.title}</h4>
        <span className={`${getBadgeStyle(insight.importance)} text-xs px-2 py-1 rounded`}>
          {insight.importance === 'normal' ? 'Updated' : 
           insight.importance === 'important' ? 'Important' : 'Urgent'}
        </span>
      </div>
      <p className="text-sm text-neutral-muted mb-4">{insight.description}</p>
      <div className="bg-neutral-light p-3 rounded-md mb-3">
        <p className="text-sm font-medium">Key Takeaway</p>
        <p className="text-sm">{insight.keyTakeaway}</p>
      </div>
      <Link href={`/market-insights/${insight.id}`}>
        <a className="text-primary text-sm font-medium flex items-center">
          Full Report
          <span className="material-icons text-sm ml-1">arrow_forward</span>
        </a>
      </Link>
    </div>
  );
};

export default InsightCard;
