import { LearningModule, UserProgress } from "@shared/schema";
import { Link } from "wouter";

interface ProgressCardProps {
  module: LearningModule;
  progress: UserProgress;
}

const ProgressCard = ({ module, progress }: ProgressCardProps) => {
  // Calculate stroke-dashoffset based on progress percentage
  const calculateStrokeDashoffset = (percentage: number) => {
    const circumference = 2 * Math.PI * 24; // 2πr where r = 24
    return circumference - (circumference * percentage) / 100;
  };

  return (
    <div className="bg-white rounded-lg shadow-sm p-4 border border-neutral-border">
      <div className="flex">
        <div className="mr-4">
          <svg width="60" height="60" viewBox="0 0 60 60" className="progress-ring">
            <circle r="24" cx="30" cy="30" fill="transparent" stroke="#DFE1E6" strokeWidth="4"></circle>
            <circle 
              r="24" 
              cx="30" 
              cy="30" 
              fill="transparent" 
              stroke="#0052CC" 
              strokeWidth="4" 
              strokeDasharray="150.8" 
              strokeDashoffset={calculateStrokeDashoffset(progress.progressPercentage)}
            ></circle>
          </svg>
        </div>
        <div className="flex-1">
          <h4 className="font-heading font-semibold mb-1">{module.title}</h4>
          <p className="text-sm text-neutral-muted mb-2">{progress.progressPercentage}% Complete</p>
          <Link href={`/learning/${module.id}`}>
            <a className="text-primary text-sm font-medium flex items-center">
              Continue
              <span className="material-icons text-sm ml-1">arrow_forward</span>
            </a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default ProgressCard;
