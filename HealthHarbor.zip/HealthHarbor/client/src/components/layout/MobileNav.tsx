import { useUser } from "@/contexts/UserContext";
import { useState } from "react";
import { Link, useLocation } from "wouter";

const MobileNav = () => {
  const [menuOpen, setMenuOpen] = useState(false);
  const [location] = useLocation();
  const { user } = useUser();

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  return (
    <>
      <div className="md:hidden bg-white border-b border-neutral-border shadow-sm z-10 flex items-center justify-between px-4 py-3">
        <button id="mobile-menu-button" className="flex items-center" onClick={toggleMenu}>
          <span className="material-icons">menu</span>
        </button>
        <div className="flex items-center">
          <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-white mr-2">
            <span className="text-lg font-bold">G</span>
          </div>
          <h1 className="font-heading font-semibold text-lg">GrowEasyAI</h1>
        </div>
        <Link href="/settings">
          <a className="flex items-center">
            <span className="material-icons">account_circle</span>
          </a>
        </Link>
      </div>

      {menuOpen && (
        <div className="fixed inset-0 bg-white z-50 md:hidden">
          <div className="flex justify-between items-center p-4 border-b border-neutral-border">
            <div className="flex items-center">
              <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-white mr-3">
                <span className="text-lg font-bold">G</span>
              </div>
              <h1 className="font-heading font-semibold text-lg">GrowEasyAI</h1>
            </div>
            <button onClick={toggleMenu}>
              <span className="material-icons">close</span>
            </button>
          </div>
          
          <div className="p-4">
            <nav className="space-y-2">
              <Link href="/">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">home</span>
                  <span>Dashboard</span>
                </a>
              </Link>
              
              <Link href="/learning">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/learning' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">school</span>
                  <span>Learning</span>
                </a>
              </Link>
              
              <Link href="/market-insights">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/market-insights' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">show_chart</span>
                  <span>Market Insights</span>
                </a>
              </Link>
              
              <Link href="/ai-mentor">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/ai-mentor' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">chat</span>
                  <span>AI Mentor</span>
                </a>
              </Link>
              
              <Link href="/resources">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/resources' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">folder</span>
                  <span>Resources</span>
                </a>
              </Link>
              
              <Link href="/settings">
                <a className={`flex items-center px-3 py-3 rounded-md ${location === '/settings' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`} onClick={toggleMenu}>
                  <span className="material-icons mr-3">settings</span>
                  <span>Settings</span>
                </a>
              </Link>
            </nav>
          </div>
          
          <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-neutral-border">
            <div className="flex items-center">
              <div className="w-10 h-10 rounded-full bg-neutral-light flex items-center justify-center">
                <span className="material-icons">person</span>
              </div>
              <div className="ml-3">
                <p className="font-medium text-sm">{user?.firstName} {user?.lastName}</p>
                <p className="text-xs text-neutral-muted">{user?.businessName || 'Business not set'}</p>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default MobileNav;
