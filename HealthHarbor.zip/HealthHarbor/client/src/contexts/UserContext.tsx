import React, { createContext, useContext, useState, useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  username: string;
  firstName: string;
  lastName: string;
  businessName?: string;
  businessType?: string;
  location?: string;
  profileCreated: string;
  lastActive: string;
}

interface UserContextType {
  user: User | null;
  loading: boolean;
  error: string | null;
  loadInitialUser: () => Promise<void>;
  login: (username: string, password: string) => Promise<boolean>;
  updateUserProfile: (userData: Partial<User>) => Promise<boolean>;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export const UserProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const loadInitialUser = useCallback(async () => {
    setLoading(true);
    try {
      // In a real app, this would fetch the current user from a session
      // For now, we'll use a hardcoded user ID for demonstration
      const userId = 1;
      const response = await apiRequest("GET", `/api/users/${userId}`);
      const data = await response.json();
      setUser(data);
      setError(null);
    } catch (err: any) {
      console.error("Failed to load user:", err);
      setError("Failed to load user profile");
      // For demo purposes, set a default user if api fails
      setUser({
        id: 1,
        username: "olawale",
        firstName: "Olawale",
        lastName: "Johnson",
        businessName: "Lagos Retail Shop",
        businessType: "Retail",
        location: "Lagos",
        profileCreated: new Date().toISOString(),
        lastActive: new Date().toISOString(),
      });
    } finally {
      setLoading(false);
    }
  }, []);

  const login = async (username: string, password: string): Promise<boolean> => {
    setLoading(true);
    try {
      // In a real app, this would be an auth API call
      // For now, we'll just simulate a login
      if (username === "olawale" && password === "password123") {
        const userId = 1;
        const response = await apiRequest("GET", `/api/users/${userId}`);
        const data = await response.json();
        setUser(data);
        setError(null);
        toast({
          title: "Logged in successfully",
          description: `Welcome back, ${data.firstName}!`,
        });
        return true;
      } else {
        setError("Invalid username or password");
        toast({
          variant: "destructive",
          title: "Login failed",
          description: "Invalid username or password",
        });
        return false;
      }
    } catch (err: any) {
      console.error("Login error:", err);
      setError(err.message || "Login failed");
      toast({
        variant: "destructive",
        title: "Login failed",
        description: err.message || "An error occurred during login",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  const updateUserProfile = async (userData: Partial<User>): Promise<boolean> => {
    if (!user) return false;
    
    setLoading(true);
    try {
      const response = await apiRequest("PATCH", `/api/users/${user.id}`, userData);
      const updatedUser = await response.json();
      setUser(updatedUser);
      setError(null);
      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });
      return true;
    } catch (err: any) {
      console.error("Update profile error:", err);
      setError(err.message || "Failed to update profile");
      toast({
        variant: "destructive",
        title: "Update failed",
        description: err.message || "Failed to update your profile",
      });
      return false;
    } finally {
      setLoading(false);
    }
  };

  return (
    <UserContext.Provider
      value={{
        user,
        loading,
        error,
        loadInitialUser,
        login,
        updateUserProfile,
      }}
    >
      {children}
    </UserContext.Provider>
  );
};

export const useUser = (): UserContextType => {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
};
