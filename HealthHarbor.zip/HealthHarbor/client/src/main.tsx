import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

// The App component will handle all providers internally
createRoot(document.getElementById("root")!).render(
  <App />
);
