import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@/contexts/UserContext";
import CourseCard from "@/components/dashboard/CourseCard";
import ProgressCard from "@/components/dashboard/ProgressCard";
import { LearningModule, UserProgress } from "@shared/schema";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";

const Learning = () => {
  const { user } = useUser();
  const [searchTerm, setSearchTerm] = useState("");
  const [activeCategory, setActiveCategory] = useState<string | null>(null);

  // Fetch all learning modules
  const { data: modulesData, isLoading: modulesLoading } = useQuery<LearningModule[]>({
    queryKey: ['/api/learning-modules']
  });

  // Fetch user progress
  const { data: progressData, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: user ? [`/api/users/${user.id}/progress`] : [null],
    enabled: !!user
  });

  // Extract unique categories from modules
  const categories = modulesData 
    ? Array.from(new Set(modulesData.map(module => module.category)))
    : [];

  // Filter modules based on search term and active category
  const filteredModules = modulesData
    ? modulesData.filter(module => {
        const matchesSearch = module.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                             module.description.toLowerCase().includes(searchTerm.toLowerCase());
        const matchesCategory = !activeCategory || module.category === activeCategory;
        return matchesSearch && matchesCategory;
      })
    : [];

  // Get modules in progress
  const modulesInProgress = progressData && modulesData
    ? progressData
        .filter(progress => progress.progressPercentage > 0 && progress.progressPercentage < 100)
        .map(progress => {
          const module = modulesData.find(m => m.id === progress.moduleId);
          return module ? { module, progress } : null;
        })
        .filter(Boolean) as { module: LearningModule, progress: UserProgress }[]
    : [];

  // Get completed modules
  const completedModules = progressData && modulesData
    ? progressData
        .filter(progress => progress.progressPercentage === 100 || progress.completed)
        .map(progress => {
          const module = modulesData.find(m => m.id === progress.moduleId);
          return module ? { module, progress } : null;
        })
        .filter(Boolean) as { module: LearningModule, progress: UserProgress }[]
    : [];

  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <div className="mb-6">
        <h2 className="font-heading text-2xl font-semibold mb-4">Learning Modules</h2>
        <div className="flex flex-col md:flex-row gap-4 items-start md:items-center">
          <Input
            type="text"
            placeholder="Search modules..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full md:w-64"
          />
          <div className="flex flex-wrap gap-2">
            <button
              className={`px-3 py-1 rounded-full text-sm ${!activeCategory ? 'bg-primary text-white' : 'bg-white border border-neutral-border text-neutral'}`}
              onClick={() => setActiveCategory(null)}
            >
              All
            </button>
            {categories.map(category => (
              <button
                key={category}
                className={`px-3 py-1 rounded-full text-sm ${activeCategory === category ? 'bg-primary text-white' : 'bg-white border border-neutral-border text-neutral'}`}
                onClick={() => setActiveCategory(category)}
              >
                {category}
              </button>
            ))}
          </div>
        </div>
      </div>

      <Tabs defaultValue="all" className="w-full">
        <TabsList className="mb-4">
          <TabsTrigger value="all">All Modules</TabsTrigger>
          <TabsTrigger value="inProgress">In Progress</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>
        
        <TabsContent value="all">
          {modulesLoading ? (
            <div className="text-center py-4">Loading modules...</div>
          ) : filteredModules.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredModules.map(module => (
                <CourseCard key={module.id} module={module} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
              <p className="text-neutral-muted">
                {searchTerm || activeCategory
                  ? "No modules match your search criteria."
                  : "No learning modules available at the moment."}
              </p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="inProgress">
          {(progressLoading || modulesLoading) ? (
            <div className="text-center py-4">Loading your progress...</div>
          ) : modulesInProgress.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {modulesInProgress.map(({ module, progress }) => (
                <ProgressCard key={module.id} module={module} progress={progress} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
              <p className="text-neutral-muted">You don't have any modules in progress.</p>
            </div>
          )}
        </TabsContent>
        
        <TabsContent value="completed">
          {(progressLoading || modulesLoading) ? (
            <div className="text-center py-4">Loading completed modules...</div>
          ) : completedModules.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {completedModules.map(({ module, progress }) => (
                <ProgressCard key={module.id} module={module} progress={progress} />
              ))}
            </div>
          ) : (
            <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
              <p className="text-neutral-muted">You haven't completed any modules yet.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Learning;
