import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useUser } from "@/contexts/UserContext";
import InsightCard from "@/components/dashboard/InsightCard";
import { MarketInsight } from "@shared/schema";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const regions = [
  "All Regions",
  "Lagos",
  "Abuja",
  "Port Harcourt",
  "Ibadan",
  "Kano",
  "National"
];

const categories = [
  "All Categories",
  "Retail",
  "Manufacturing",
  "Agriculture",
  "Technology",
  "Supply Chain",
  "Finance"
];

const MarketInsights = () => {
  const { user } = useUser();
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedRegion, setSelectedRegion] = useState("All Regions");
  const [selectedCategory, setSelectedCategory] = useState("All Categories");
  const [selectedImportance, setSelectedImportance] = useState("All");

  // Fetch market insights
  const { data: insightsData, isLoading } = useQuery<MarketInsight[]>({
    queryKey: ['/api/market-insights']
  });

  // Filter insights based on search, region, category, and importance
  const filteredInsights = insightsData
    ? insightsData.filter(insight => {
        const matchesSearch = 
          insight.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
          insight.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
          insight.keyTakeaway.toLowerCase().includes(searchTerm.toLowerCase());
        
        const matchesRegion = 
          selectedRegion === "All Regions" || 
          insight.region === selectedRegion;
        
        const matchesCategory = 
          selectedCategory === "All Categories" || 
          insight.category === selectedCategory;
        
        const matchesImportance = 
          selectedImportance === "All" || 
          insight.importance === selectedImportance.toLowerCase();
        
        return matchesSearch && matchesRegion && matchesCategory && matchesImportance;
      })
    : [];

  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <div className="mb-6">
        <h2 className="font-heading text-2xl font-semibold mb-4">Market Insights</h2>
        <p className="text-neutral-muted mb-4">
          Stay updated with the latest market trends and information relevant to your business.
        </p>
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Input
            type="text"
            placeholder="Search insights..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full"
          />
          
          <Select value={selectedRegion} onValueChange={setSelectedRegion}>
            <SelectTrigger>
              <SelectValue placeholder="Select region" />
            </SelectTrigger>
            <SelectContent>
              {regions.map(region => (
                <SelectItem key={region} value={region}>{region}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedCategory} onValueChange={setSelectedCategory}>
            <SelectTrigger>
              <SelectValue placeholder="Select category" />
            </SelectTrigger>
            <SelectContent>
              {categories.map(category => (
                <SelectItem key={category} value={category}>{category}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          
          <Select value={selectedImportance} onValueChange={setSelectedImportance}>
            <SelectTrigger>
              <SelectValue placeholder="Filter by importance" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="All">All</SelectItem>
              <SelectItem value="Normal">Normal</SelectItem>
              <SelectItem value="Important">Important</SelectItem>
              <SelectItem value="Urgent">Urgent</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        <div className="text-center py-4">Loading insights...</div>
      ) : filteredInsights.length > 0 ? (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {filteredInsights.map(insight => (
            <InsightCard key={insight.id} insight={insight} />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
          <p className="text-neutral-muted">
            {searchTerm || selectedRegion !== "All Regions" || selectedCategory !== "All Categories" || selectedImportance !== "All"
              ? "No insights match your search criteria."
              : "No market insights available at the moment."}
          </p>
        </div>
      )}
    </div>
  );
};

export default MarketInsights;
