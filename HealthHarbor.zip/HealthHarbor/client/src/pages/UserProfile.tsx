import { useState } from "react";
import { useUser } from "@/contexts/UserContext";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import { 
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserProgress, ProfileQuestion, UserAnswer } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";

const nigerianRegions = [
  "Lagos",
  "Abuja",
  "Port Harcourt",
  "Ibadan",
  "Kano",
  "Enugu",
  "Benin City",
  "Kaduna",
  "Calabar",
  "Owerri",
  "Uyo",
  "Jos",
  "Other"
];

const businessTypes = [
  "Retail",
  "Wholesale",
  "Manufacturing",
  "Agriculture",
  "Technology",
  "Services",
  "Food & Beverage",
  "Construction",
  "Healthcare",
  "Education",
  "Transportation",
  "Other"
];

const profileFormSchema = z.object({
  firstName: z.string().min(2, "First name must be at least 2 characters"),
  lastName: z.string().min(2, "Last name must be at least 2 characters"),
  businessName: z.string().min(1, "Business name is required"),
  businessType: z.string().min(1, "Business type is required"),
  location: z.string().min(1, "Location is required"),
});

const UserProfile = () => {
  const { user, updateUserProfile } = useUser();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Fetch user progress
  const { data: progressData, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: user ? [`/api/users/${user.id}/progress`] : [null],
    enabled: !!user
  });
  
  // Fetch profile questions
  const { data: questionsData, isLoading: questionsLoading } = useQuery<ProfileQuestion[]>({
    queryKey: ['/api/profile-questions']
  });
  
  // Fetch user answers
  const { data: answersData, isLoading: answersLoading } = useQuery<UserAnswer[]>({
    queryKey: user ? [`/api/users/${user.id}/answers`] : [null],
    enabled: !!user
  });
  
  // Profile form
  const form = useForm<z.infer<typeof profileFormSchema>>({
    resolver: zodResolver(profileFormSchema),
    defaultValues: {
      firstName: user?.firstName || "",
      lastName: user?.lastName || "",
      businessName: user?.businessName || "",
      businessType: user?.businessType || "",
      location: user?.location || "",
    },
  });
  
  const onSubmit = async (data: z.infer<typeof profileFormSchema>) => {
    setIsSubmitting(true);
    try {
      const success = await updateUserProfile(data);
      if (success) {
        toast({
          title: "Profile updated",
          description: "Your profile information has been updated successfully."
        });
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Update failed",
        description: "There was a problem updating your profile."
      });
    } finally {
      setIsSubmitting(false);
    }
  };
  
  // Calculate profile completeness
  const calculateProfileCompleteness = (): number => {
    if (!user) return 0;
    
    let completedFields = 0;
    let totalFields = 5; // firstName, lastName, businessName, businessType, location
    
    if (user.firstName) completedFields++;
    if (user.lastName) completedFields++;
    if (user.businessName) completedFields++;
    if (user.businessType) completedFields++;
    if (user.location) completedFields++;
    
    return Math.round((completedFields / totalFields) * 100);
  };
  
  const profileCompleteness = calculateProfileCompleteness();
  
  // Get completed modules count
  const getCompletedModulesCount = (): number => {
    if (!progressData) return 0;
    return progressData.filter(progress => progress.completed || progress.progressPercentage === 100).length;
  };
  
  const completedModules = getCompletedModulesCount();
  
  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <div className="mb-6">
        <h2 className="font-heading text-2xl font-semibold mb-2">Your Profile</h2>
        <p className="text-neutral-muted">
          View and manage your entrepreneur profile.
        </p>
      </div>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left Column - Profile Summary */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Profile Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col items-center">
              <div className="w-24 h-24 rounded-full bg-neutral-light flex items-center justify-center mb-4">
                <span className="material-icons text-4xl">person</span>
              </div>
              <h3 className="text-xl font-semibold mb-1">{user?.firstName} {user?.lastName}</h3>
              <p className="text-neutral-muted mb-4">{user?.businessName || "Business Name Not Set"}</p>
              
              <div className="w-full mb-6">
                <div className="flex justify-between mb-1">
                  <span className="text-sm">Profile Completeness</span>
                  <span className="text-sm font-medium">{profileCompleteness}%</span>
                </div>
                <div className="w-full h-2 bg-neutral-light rounded-full">
                  <div 
                    className="h-2 bg-primary rounded-full" 
                    style={{ width: `${profileCompleteness}%` }}
                  ></div>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4 w-full">
                <div className="bg-neutral-light p-3 rounded-md text-center">
                  <p className="text-2xl font-semibold text-primary">{completedModules}</p>
                  <p className="text-sm text-neutral-muted">Modules Completed</p>
                </div>
                <div className="bg-neutral-light p-3 rounded-md text-center">
                  <p className="text-2xl font-semibold text-primary">{progressData?.length || 0}</p>
                  <p className="text-sm text-neutral-muted">Modules Started</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
        
        {/* Right Column - Profile Details */}
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle>Business Profile</CardTitle>
            <CardDescription>
              Update your personal and business information to get personalized recommendations.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="details" className="w-full">
              <TabsList className="mb-4">
                <TabsTrigger value="details">Business Details</TabsTrigger>
                <TabsTrigger value="assessment">Business Assessment</TabsTrigger>
              </TabsList>
              
              <TabsContent value="details">
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your first name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name</FormLabel>
                            <FormControl>
                              <Input placeholder="Your last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <FormField
                      control={form.control}
                      name="businessName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Business Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Your business name" {...field} />
                          </FormControl>
                          <FormDescription>
                            The name of your business or startup
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <FormField
                        control={form.control}
                        name="businessType"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Type</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select business type" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {businessTypes.map(type => (
                                  <SelectItem key={type} value={type}>
                                    {type}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                      
                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location</FormLabel>
                            <Select 
                              onValueChange={field.onChange} 
                              defaultValue={field.value}
                            >
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your region" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {nigerianRegions.map(region => (
                                  <SelectItem key={region} value={region}>
                                    {region}
                                  </SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                    
                    <Button 
                      type="submit" 
                      className="bg-primary hover:bg-primary-dark"
                      disabled={isSubmitting}
                    >
                      {isSubmitting ? (
                        <>
                          <span className="material-icons animate-spin mr-2">refresh</span>
                          Saving...
                        </>
                      ) : (
                        <>Save Changes</>
                      )}
                    </Button>
                  </form>
                </Form>
              </TabsContent>
              
              <TabsContent value="assessment">
                {(questionsLoading || answersLoading) ? (
                  <div className="py-8 text-center">
                    <span className="material-icons animate-spin mr-2">refresh</span>
                    Loading assessment...
                  </div>
                ) : questionsData && questionsData.length > 0 ? (
                  <div className="space-y-6">
                    <p className="text-neutral-muted mb-4">
                      Answer these questions to help us understand your business better and provide tailored recommendations.
                    </p>
                    
                    {questionsData.map((question, index) => {
                      // Find user answer for this question if it exists
                      const answer = answersData?.find(a => a.questionId === question.id);
                      
                      return (
                        <div key={question.id} className="space-y-2">
                          <h3 className="text-md font-medium">{index + 1}. {question.question}</h3>
                          <Select 
                            defaultValue={answer?.answer || ''}
                            onValueChange={(value) => {
                              // In a real app, this would save the answer to the server
                              toast({
                                title: "Answer saved",
                                description: "Your response has been recorded."
                              });
                            }}
                          >
                            <SelectTrigger className="w-full">
                              <SelectValue placeholder="Select your answer" />
                            </SelectTrigger>
                            <SelectContent>
                              {question.options.map((option, i) => (
                                <SelectItem key={i} value={option}>{option}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          {index < questionsData.length - 1 && <Separator className="my-4" />}
                        </div>
                      );
                    })}
                    
                    <Button className="bg-primary hover:bg-primary-dark">
                      Submit Assessment
                    </Button>
                  </div>
                ) : (
                  <div className="py-8 text-center">
                    <p className="text-neutral-muted">No assessment questions available at the moment.</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default UserProfile;
