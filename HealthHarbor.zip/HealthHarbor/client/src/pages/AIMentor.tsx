import { useState, useRef, useEffect } from "react";
import { useChat } from "@/contexts/ChatContext";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Separator } from "@/components/ui/separator";

// Suggested questions to help users get started
const suggestedQuestions = [
  "How can I improve my cash flow?",
  "What marketing strategies work best for small retailers in Lagos?",
  "How can I reduce inventory costs?",
  "What permits do I need to start a food business in Nigeria?",
  "How should I price my products for maximum profit?",
  "What business grants are available for Nigerian entrepreneurs?",
  "How can I hire and retain good employees?",
  "What digital tools should I use for my business?",
];

const AIMentor = () => {
  const { messages, loading, sendMessage } = useChat();
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Ensure chat opens fully on this page
  useEffect(() => {
    // Note: no need to call openChat here since the chat will be displayed directly on the page
  }, []);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      sendMessage(inputValue);
      setInputValue("");
    }
  };

  const handleSuggestedQuestion = (question: string) => {
    sendMessage(question);
  };

  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chat Interface - Takes up 2/3 of the space on desktop */}
        <Card className="col-span-1 lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center">
              <span className="material-icons mr-2 text-primary">smart_toy</span>
              AI Business Mentor
            </CardTitle>
            <CardDescription>
              Ask any business question and get personalized advice for your Nigerian business.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ScrollArea className="h-[500px] p-4 rounded-md border">
              {messages.length === 0 ? (
                <div className="flex flex-col items-center justify-center h-full text-center">
                  <span className="material-icons text-4xl text-primary mb-2">chat</span>
                  <h3 className="text-lg font-medium mb-1">Start a conversation</h3>
                  <p className="text-neutral-muted">Ask your business question or select a suggested question below.</p>
                </div>
              ) : (
                messages.map((message, index) => (
                  <div key={message.id || index} className={`flex mb-4 ${message.sender === 'user' ? 'justify-end' : ''}`}>
                    {message.sender === 'ai' && (
                      <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
                        <span className="material-icons text-sm">smart_toy</span>
                      </div>
                    )}
                    
                    <div className={`ml-2 mr-2 chat-message ${message.sender === 'ai' ? 'bot-message bg-neutral-light' : 'user-message bg-primary bg-opacity-10'} rounded-lg p-3 ${message.sender === 'user' ? 'mr-2' : 'ml-2'}`} style={{ maxWidth: '85%' }}>
                      <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    </div>
                    
                    {message.sender === 'user' && (
                      <div className="w-8 h-8 rounded-full bg-neutral-muted flex items-center justify-center text-white flex-shrink-0">
                        <span className="material-icons text-sm">person</span>
                      </div>
                    )}
                  </div>
                ))
              )}
              {loading && (
                <div className="flex mb-4">
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
                    <span className="material-icons text-sm">smart_toy</span>
                  </div>
                  <div className="ml-2 chat-message bot-message bg-neutral-light rounded-lg p-3" style={{ maxWidth: '85%' }}>
                    <div className="flex space-x-2 items-center">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </ScrollArea>
          </CardContent>
          <CardFooter>
            <form onSubmit={handleSendMessage} className="w-full flex">
              <Input
                type="text"
                placeholder="Type your business question..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 mr-2"
                disabled={loading}
              />
              <Button 
                type="submit" 
                disabled={loading || !inputValue.trim()}
                className="bg-primary hover:bg-primary-dark text-white"
              >
                <span className="material-icons mr-1">send</span>
                Send
              </Button>
            </form>
          </CardFooter>
        </Card>
        
        {/* Suggestions Panel - Takes up 1/3 of the space on desktop */}
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Suggested Questions</CardTitle>
            <CardDescription>
              Not sure what to ask? Try one of these common business questions.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {suggestedQuestions.map((question, index) => (
                <div key={index}>
                  <Button 
                    variant="outline" 
                    className="w-full justify-start text-left h-auto py-2"
                    onClick={() => handleSuggestedQuestion(question)}
                    disabled={loading}
                  >
                    {question}
                  </Button>
                  {index < suggestedQuestions.length - 1 && <Separator className="my-2" />}
                </div>
              ))}
            </div>
          </CardContent>
          <CardFooter>
            <p className="text-xs text-neutral-muted">
              Our AI mentor provides general business advice. For legal, financial, or health matters, please consult qualified professionals.
            </p>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default AIMentor;
