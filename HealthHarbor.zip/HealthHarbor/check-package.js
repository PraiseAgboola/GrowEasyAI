const fs = require('fs');
const path = require('path');

// Check if package.json exists in current directory
try {
  const packageJsonPath = path.join(process.cwd(), 'package.json');
  const exists = fs.existsSync(packageJsonPath);
  console.log(`package.json exists: ${exists}`);
  if (exists) {
    const packageJson = require(packageJsonPath);
    console.log(`Package name: ${packageJson.name}`);
    console.log(`Node version: ${process.version}`);
    console.log(`Current directory: ${process.cwd()}`);
    console.log(`Directory contents:`);
    fs.readdirSync(process.cwd()).forEach(file => {
      console.log(`- ${file}`);
    });
  }
} catch (error) {
  console.error(`Error checking package.json: ${error.message}`);
}