import { 
  users, chatConversations, chatMessages, learningModules, 
  marketInsights, offlineContent, profileQuestions, 
  userAnswers, userProgress,
  type User, type InsertUser, 
  type LearningModule, type InsertLearningModule,
  type UserProgress, type InsertUserProgress,
  type MarketInsight, type InsertMarketInsight,
  type ChatConversation, type InsertChatConversation,
  type ChatMessage, type InsertChatMessage,
  type ProfileQuestion, type InsertProfileQuestion,
  type UserAnswer, type InsertUserAnswer,
  type OfflineContent, type InsertOfflineContent
} from "@shared/schema";

// Define the storage interface for all CRUD operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined>;
  
  // Learning modules operations
  getLearningModules(): Promise<LearningModule[]>;
  getLearningModule(id: number): Promise<LearningModule | undefined>;
  getLearningModulesByCategory(category: string): Promise<LearningModule[]>;
  createLearningModule(module: InsertLearningModule): Promise<LearningModule>;
  
  // User progress operations
  getUserProgress(userId: number): Promise<UserProgress[]>;
  getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined>;
  createUserProgress(progress: InsertUserProgress): Promise<UserProgress>;
  updateUserProgress(userId: number, moduleId: number, progressData: Partial<InsertUserProgress>): Promise<UserProgress | undefined>;
  
  // Market insight operations
  getMarketInsights(): Promise<MarketInsight[]>;
  getMarketInsight(id: number): Promise<MarketInsight | undefined>;
  getMarketInsightsByRegion(region: string): Promise<MarketInsight[]>;
  createMarketInsight(insight: InsertMarketInsight): Promise<MarketInsight>;
  
  // Chat conversation operations
  getChatConversations(userId: number): Promise<ChatConversation[]>;
  getChatConversation(id: number): Promise<ChatConversation | undefined>;
  createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation>;
  
  // Chat message operations
  getChatMessages(conversationId: number): Promise<ChatMessage[]>;
  createChatMessage(message: InsertChatMessage): Promise<ChatMessage>;
  
  // Profile questions operations
  getProfileQuestions(): Promise<ProfileQuestion[]>;
  getProfileQuestionsByCategory(category: string): Promise<ProfileQuestion[]>;
  createProfileQuestion(question: InsertProfileQuestion): Promise<ProfileQuestion>;
  
  // User answers operations
  getUserAnswers(userId: number): Promise<UserAnswer[]>;
  createUserAnswer(answer: InsertUserAnswer): Promise<UserAnswer>;
  
  // Offline content operations
  getUserOfflineContent(userId: number): Promise<OfflineContent[]>;
  createOfflineContent(content: InsertOfflineContent): Promise<OfflineContent>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private learningModules: Map<number, LearningModule>;
  private userProgress: Map<string, UserProgress>; // composite key: userId-moduleId
  private marketInsights: Map<number, MarketInsight>;
  private chatConversations: Map<number, ChatConversation>;
  private chatMessages: Map<number, ChatMessage>;
  private profileQuestions: Map<number, ProfileQuestion>;
  private userAnswers: Map<number, UserAnswer>;
  private offlineContent: Map<number, OfflineContent>;
  
  // Auto-incrementing IDs
  private userIdCounter: number;
  private moduleIdCounter: number;
  private progressIdCounter: number;
  private insightIdCounter: number;
  private conversationIdCounter: number;
  private messageIdCounter: number;
  private questionIdCounter: number;
  private answerIdCounter: number;
  private contentIdCounter: number;

  constructor() {
    this.users = new Map();
    this.learningModules = new Map();
    this.userProgress = new Map();
    this.marketInsights = new Map();
    this.chatConversations = new Map();
    this.chatMessages = new Map();
    this.profileQuestions = new Map();
    this.userAnswers = new Map();
    this.offlineContent = new Map();
    
    this.userIdCounter = 1;
    this.moduleIdCounter = 1;
    this.progressIdCounter = 1;
    this.insightIdCounter = 1;
    this.conversationIdCounter = 1;
    this.messageIdCounter = 1;
    this.questionIdCounter = 1;
    this.answerIdCounter = 1;
    this.contentIdCounter = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const now = new Date();
    const user: User = { 
      ...insertUser, 
      id,
      profileCreated: now,
      lastActive: now 
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) {
      return undefined;
    }
    
    const updatedUser: User = {
      ...user,
      ...userData,
      lastActive: new Date()
    };
    
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Learning modules operations
  async getLearningModules(): Promise<LearningModule[]> {
    return Array.from(this.learningModules.values());
  }

  async getLearningModule(id: number): Promise<LearningModule | undefined> {
    return this.learningModules.get(id);
  }

  async getLearningModulesByCategory(category: string): Promise<LearningModule[]> {
    return Array.from(this.learningModules.values()).filter(
      (module) => module.category === category
    );
  }

  async createLearningModule(module: InsertLearningModule): Promise<LearningModule> {
    const id = this.moduleIdCounter++;
    const learningModule: LearningModule = { ...module, id };
    this.learningModules.set(id, learningModule);
    return learningModule;
  }

  // User progress operations
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return Array.from(this.userProgress.values()).filter(
      (progress) => progress.userId === userId
    );
  }

  async getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    return this.userProgress.get(`${userId}-${moduleId}`);
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const id = this.progressIdCounter++;
    const now = new Date();
    const userProgress: UserProgress = { 
      ...progress, 
      id, 
      lastUpdated: now 
    };
    this.userProgress.set(`${progress.userId}-${progress.moduleId}`, userProgress);
    return userProgress;
  }

  async updateUserProgress(userId: number, moduleId: number, progressData: Partial<InsertUserProgress>): Promise<UserProgress | undefined> {
    const key = `${userId}-${moduleId}`;
    const progress = this.userProgress.get(key);
    
    if (!progress) {
      return undefined;
    }
    
    const updatedProgress: UserProgress = {
      ...progress,
      ...progressData,
      lastUpdated: new Date()
    };
    
    this.userProgress.set(key, updatedProgress);
    return updatedProgress;
  }

  // Market insight operations
  async getMarketInsights(): Promise<MarketInsight[]> {
    return Array.from(this.marketInsights.values());
  }

  async getMarketInsight(id: number): Promise<MarketInsight | undefined> {
    return this.marketInsights.get(id);
  }

  async getMarketInsightsByRegion(region: string): Promise<MarketInsight[]> {
    return Array.from(this.marketInsights.values()).filter(
      (insight) => insight.region === region
    );
  }

  async createMarketInsight(insight: InsertMarketInsight): Promise<MarketInsight> {
    const id = this.insightIdCounter++;
    const now = new Date();
    const marketInsight: MarketInsight = { 
      ...insight, 
      id, 
      publishedDate: now 
    };
    this.marketInsights.set(id, marketInsight);
    return marketInsight;
  }

  // Chat conversation operations
  async getChatConversations(userId: number): Promise<ChatConversation[]> {
    return Array.from(this.chatConversations.values()).filter(
      (conversation) => conversation.userId === userId
    );
  }

  async getChatConversation(id: number): Promise<ChatConversation | undefined> {
    return this.chatConversations.get(id);
  }

  async createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const id = this.conversationIdCounter++;
    const now = new Date();
    const chatConversation: ChatConversation = { 
      ...conversation, 
      id, 
      startTime: now, 
      lastMessageTime: now 
    };
    this.chatConversations.set(id, chatConversation);
    return chatConversation;
  }

  // Chat message operations
  async getChatMessages(conversationId: number): Promise<ChatMessage[]> {
    return Array.from(this.chatMessages.values()).filter(
      (message) => message.conversationId === conversationId
    );
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const id = this.messageIdCounter++;
    const now = new Date();
    const chatMessage: ChatMessage = { 
      ...message, 
      id, 
      timestamp: now 
    };
    this.chatMessages.set(id, chatMessage);
    
    // Update conversation last message time
    const conversation = this.chatConversations.get(message.conversationId);
    if (conversation) {
      this.chatConversations.set(message.conversationId, {
        ...conversation,
        lastMessageTime: now
      });
    }
    
    return chatMessage;
  }

  // Profile questions operations
  async getProfileQuestions(): Promise<ProfileQuestion[]> {
    return Array.from(this.profileQuestions.values());
  }

  async getProfileQuestionsByCategory(category: string): Promise<ProfileQuestion[]> {
    return Array.from(this.profileQuestions.values()).filter(
      (question) => question.category === category
    );
  }

  async createProfileQuestion(question: InsertProfileQuestion): Promise<ProfileQuestion> {
    const id = this.questionIdCounter++;
    const profileQuestion: ProfileQuestion = { ...question, id };
    this.profileQuestions.set(id, profileQuestion);
    return profileQuestion;
  }

  // User answers operations
  async getUserAnswers(userId: number): Promise<UserAnswer[]> {
    return Array.from(this.userAnswers.values()).filter(
      (answer) => answer.userId === userId
    );
  }

  async createUserAnswer(answer: InsertUserAnswer): Promise<UserAnswer> {
    const id = this.answerIdCounter++;
    const now = new Date();
    const userAnswer: UserAnswer = { 
      ...answer, 
      id, 
      timestamp: now 
    };
    this.userAnswers.set(id, userAnswer);
    return userAnswer;
  }

  // Offline content operations
  async getUserOfflineContent(userId: number): Promise<OfflineContent[]> {
    return Array.from(this.offlineContent.values()).filter(
      (content) => content.userId === userId
    );
  }

  async createOfflineContent(content: InsertOfflineContent): Promise<OfflineContent> {
    const id = this.contentIdCounter++;
    const now = new Date();
    const offlineContent: OfflineContent = { 
      ...content, 
      id, 
      cachedAt: now 
    };
    this.offlineContent.set(id, offlineContent);
    return offlineContent;
  }

  // Initialize with sample data
  private initializeSampleData() {
    // Create a sample user
    const sampleUser: InsertUser = {
      username: "olawale",
      password: "password123",
      firstName: "Olawale",
      lastName: "Johnson",
      businessName: "Lagos Retail Shop",
      businessType: "Retail",
      location: "Lagos",
    };
    this.createUser(sampleUser);

    // Create sample learning modules
    const financialModule: InsertLearningModule = {
      title: "Financial Management",
      description: "Learn the fundamentals of financial management for small businesses",
      category: "Finance",
      duration: 60,
      content: "Complete financial management module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(financialModule);

    const marketingModule: InsertLearningModule = {
      title: "Marketing Essentials",
      description: "Essential marketing strategies for small businesses",
      category: "Marketing",
      duration: 45,
      content: "Complete marketing essentials module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(marketingModule);

    const supplyModule: InsertLearningModule = {
      title: "Supply Chain Basics",
      description: "Introduction to supply chain management",
      category: "Operations",
      duration: 30,
      content: "Complete supply chain basics module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(supplyModule);

    // Create sample recommended modules
    const cashFlowModule: InsertLearningModule = {
      title: "Cash Flow Management for Small Businesses",
      description: "Learn essential strategies to manage your business cash flow effectively.",
      category: "Finance",
      duration: 45,
      content: "Complete cash flow management module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(cashFlowModule);

    const digitalMarketingModule: InsertLearningModule = {
      title: "Low-Cost Digital Marketing Strategies",
      description: "Simple digital marketing approaches that won't break your budget.",
      category: "Marketing",
      duration: 30,
      content: "Complete digital marketing module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1556761175-4b46a572b786?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(digitalMarketingModule);

    const inventoryModule: InsertLearningModule = {
      title: "Inventory Management for Retailers",
      description: "Track and optimize your inventory to maximize profits.",
      category: "Operations",
      duration: 25,
      content: "Complete inventory management module content goes here...",
      imageUrl: "https://images.unsplash.com/photo-1450101499163-c8848c66ca85?ixlib=rb-1.2.1&auto=format&fit=crop&w=600&q=80"
    };
    this.createLearningModule(inventoryModule);

    // Create sample user progress entries
    const progress1: InsertUserProgress = {
      userId: 1,
      moduleId: 1,
      progressPercentage: 70,
      completed: false
    };
    this.createUserProgress(progress1);

    const progress2: InsertUserProgress = {
      userId: 1,
      moduleId: 2,
      progressPercentage: 40,
      completed: false
    };
    this.createUserProgress(progress2);

    const progress3: InsertUserProgress = {
      userId: 1,
      moduleId: 3,
      progressPercentage: 20,
      completed: false
    };
    this.createUserProgress(progress3);

    // Create sample market insights
    const insight1: InsertMarketInsight = {
      title: "Lagos Retail Trends",
      description: "Retail sales in Lagos have increased by 12% in the last quarter, with highest growth in consumer electronics and home goods.",
      category: "Retail",
      region: "Lagos",
      importance: "normal",
      keyTakeaway: "Consider expanding your inventory with trending electronic accessories and home improvement items.",
      content: "Full detailed report on Lagos retail trends..."
    };
    this.createMarketInsight(insight1);

    const insight2: InsertMarketInsight = {
      title: "Supply Chain Alert",
      description: "Expected shipping delays from Asian manufacturers due to port congestion. Average delay increased to 14 days.",
      category: "Supply Chain",
      region: "National",
      importance: "important",
      keyTakeaway: "Order inventory earlier than usual and consider alternative suppliers within Nigeria or West Africa.",
      content: "Full detailed report on supply chain issues..."
    };
    this.createMarketInsight(insight2);

    // Create sample profile questions
    const question1: InsertProfileQuestion = {
      question: "What type of business do you run?",
      options: ["Retail", "Service", "Manufacturing", "Agriculture", "Technology", "Other"],
      category: "Business Type"
    };
    this.createProfileQuestion(question1);

    const question2: InsertProfileQuestion = {
      question: "How many employees do you have?",
      options: ["Just me", "2-5", "6-10", "11-20", "More than 20"],
      category: "Business Size"
    };
    this.createProfileQuestion(question2);

    const question3: InsertProfileQuestion = {
      question: "What's your biggest challenge in business right now?",
      options: ["Cash flow", "Marketing", "Operations", "Human resources", "Supply chain", "Competition"],
      category: "Business Challenges"
    };
    this.createProfileQuestion(question3);
  }
}

// Import the PostgreSQL storage implementation
import { pgStorage } from "./pgStorage";

// Export the storage instance - using PostgreSQL instead of in-memory storage
export const storage = pgStorage;
