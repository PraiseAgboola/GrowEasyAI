import {
  User, InsertUser,
  LearningModule, InsertLearningModule,
  UserProgress, InsertUserProgress,
  MarketInsight, InsertMarketInsight,
  ChatConversation, InsertChatConversation,
  ChatMessage, InsertChatMessage,
  ProfileQuestion, InsertProfileQuestion,
  UserAnswer, InsertUserAnswer,
  OfflineContent, InsertOfflineContent,
  users,
  learningModules,
  userProgress,
  marketInsights,
  chatConversations,
  chatMessages,
  profileQuestions,
  userAnswers,
  offlineContent
} from "../shared/schema";
import { IStorage } from "./storage";
import { eq, and } from "drizzle-orm";
import { db } from "./db";

export class PgStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(user: InsertUser): Promise<User> {
    const result = await db.insert(users).values(user).returning();
    return result[0];
  }

  async updateUser(id: number, userData: Partial<InsertUser>): Promise<User | undefined> {
    const result = await db.update(users)
      .set({
        ...userData,
        lastActive: new Date()
      })
      .where(eq(users.id, id))
      .returning();
    return result[0];
  }

  // Learning modules operations
  async getLearningModules(): Promise<LearningModule[]> {
    return await db.select().from(learningModules);
  }

  async getLearningModule(id: number): Promise<LearningModule | undefined> {
    const result = await db.select().from(learningModules).where(eq(learningModules.id, id));
    return result[0];
  }

  async getLearningModulesByCategory(category: string): Promise<LearningModule[]> {
    return await db.select().from(learningModules).where(eq(learningModules.category, category));
  }

  async createLearningModule(module: InsertLearningModule): Promise<LearningModule> {
    const result = await db.insert(learningModules).values(module).returning();
    return result[0];
  }

  // User progress operations
  async getUserProgress(userId: number): Promise<UserProgress[]> {
    return await db.select().from(userProgress).where(eq(userProgress.userId, userId));
  }

  async getUserModuleProgress(userId: number, moduleId: number): Promise<UserProgress | undefined> {
    const result = await db.select().from(userProgress).where(
      and(
        eq(userProgress.userId, userId),
        eq(userProgress.moduleId, moduleId)
      )
    );
    return result[0];
  }

  async createUserProgress(progress: InsertUserProgress): Promise<UserProgress> {
    const result = await db.insert(userProgress).values(progress).returning();
    return result[0];
  }

  async updateUserProgress(userId: number, moduleId: number, progressData: Partial<InsertUserProgress>): Promise<UserProgress | undefined> {
    const result = await db.update(userProgress)
      .set({
        ...progressData,
        lastUpdated: new Date()
      })
      .where(
        and(
          eq(userProgress.userId, userId),
          eq(userProgress.moduleId, moduleId)
        )
      )
      .returning();
    return result[0];
  }

  // Market insight operations
  async getMarketInsights(): Promise<MarketInsight[]> {
    return await db.select().from(marketInsights);
  }

  async getMarketInsight(id: number): Promise<MarketInsight | undefined> {
    const result = await db.select().from(marketInsights).where(eq(marketInsights.id, id));
    return result[0];
  }

  async getMarketInsightsByRegion(region: string): Promise<MarketInsight[]> {
    return await db.select().from(marketInsights).where(eq(marketInsights.region, region));
  }

  async createMarketInsight(insight: InsertMarketInsight): Promise<MarketInsight> {
    const result = await db.insert(marketInsights).values(insight).returning();
    return result[0];
  }

  // Chat conversation operations
  async getChatConversations(userId: number): Promise<ChatConversation[]> {
    return await db.select().from(chatConversations).where(eq(chatConversations.userId, userId));
  }

  async getChatConversation(id: number): Promise<ChatConversation | undefined> {
    const result = await db.select().from(chatConversations).where(eq(chatConversations.id, id));
    return result[0];
  }

  async createChatConversation(conversation: InsertChatConversation): Promise<ChatConversation> {
    const result = await db.insert(chatConversations).values(conversation).returning();
    return result[0];
  }

  // Chat message operations
  async getChatMessages(conversationId: number): Promise<ChatMessage[]> {
    return await db.select().from(chatMessages).where(eq(chatMessages.conversationId, conversationId));
  }

  async createChatMessage(message: InsertChatMessage): Promise<ChatMessage> {
    const result = await db.insert(chatMessages).values(message).returning();
    return result[0];
  }

  // Profile questions operations
  async getProfileQuestions(): Promise<ProfileQuestion[]> {
    return await db.select().from(profileQuestions);
  }

  async getProfileQuestionsByCategory(category: string): Promise<ProfileQuestion[]> {
    return await db.select().from(profileQuestions).where(eq(profileQuestions.category, category));
  }

  async createProfileQuestion(question: InsertProfileQuestion): Promise<ProfileQuestion> {
    const result = await db.insert(profileQuestions).values(question).returning();
    return result[0];
  }

  // User answers operations
  async getUserAnswers(userId: number): Promise<UserAnswer[]> {
    return await db.select().from(userAnswers).where(eq(userAnswers.userId, userId));
  }

  async createUserAnswer(answer: InsertUserAnswer): Promise<UserAnswer> {
    const result = await db.insert(userAnswers).values(answer).returning();
    return result[0];
  }

  // Offline content operations
  async getUserOfflineContent(userId: number): Promise<OfflineContent[]> {
    return await db.select().from(offlineContent).where(eq(offlineContent.userId, userId));
  }

  async createOfflineContent(content: InsertOfflineContent): Promise<OfflineContent> {
    const result = await db.insert(offlineContent).values(content).returning();
    return result[0];
  }

  // Initialize the database with sample data
  async initializeSampleData() {
    // Check if users table already has data
    const existingUsers = await db.select().from(users);
    if (existingUsers.length > 0) {
      console.log("Database already has sample data");
      return;
    }

    console.log("Initializing database with sample data...");

    // Create sample user
    const sampleUser = {
      username: "olawale",
      password: "password123", // In production, this would be hashed
      firstName: "Olawale",
      lastName: "Johnson",
      businessName: "Lagos Retail Shop",
      businessType: "Retail",
      location: "Lagos"
    };
    
    const user = await this.createUser(sampleUser);

    // Create sample learning modules
    const financialModule = {
      title: "Financial Management",
      description: "Learn essential financial management skills for small businesses",
      category: "Finance",
      duration: 45,
      content: "# Financial Management for Small Businesses\n\nThis module covers basic financial concepts including:\n\n- Cash flow management\n- Budgeting strategies\n- Pricing your products\n- Record keeping\n\n## Introduction\n\nProper financial management is critical for business success...",
      imageUrl: "/assets/financial-management.jpg"
    };
    
    const marketingModule = {
      title: "Marketing Essentials",
      description: "Marketing strategies for small businesses in Nigeria",
      category: "Marketing",
      duration: 60,
      content: "# Marketing Essentials for Nigerian Entrepreneurs\n\nThis module covers key marketing concepts including:\n\n- Understanding your target market\n- Creating a unique value proposition\n- Local marketing strategies\n- Digital marketing basics\n\n## Understanding Your Market\n\nKnowing your customer is the foundation of effective marketing...",
      imageUrl: "/assets/marketing.jpg"
    };
    
    const supplyModule = {
      title: "Supply Chain Management",
      description: "Optimize your supply chain for efficiency and reliability",
      category: "Operations",
      duration: 55,
      content: "# Supply Chain Management\n\nThis module covers essential supply chain concepts including:\n\n- Supplier selection and management\n- Inventory optimization\n- Transportation and logistics\n- Managing supply disruptions\n\n## Building Resilient Supply Chains\n\nA resilient supply chain is critical for business continuity...",
      imageUrl: "/assets/supply-chain.jpg"
    };
    
    const module1 = await this.createLearningModule(financialModule);
    const module2 = await this.createLearningModule(marketingModule);
    const module3 = await this.createLearningModule(supplyModule);

    // Create sample user progress
    const progress1 = {
      userId: user.id,
      moduleId: module1.id,
      progressPercentage: 75,
      completed: false
    };
    
    const progress2 = {
      userId: user.id,
      moduleId: module2.id,
      progressPercentage: 100,
      completed: true
    };
    
    const progress3 = {
      userId: user.id,
      moduleId: module3.id,
      progressPercentage: 10,
      completed: false
    };
    
    await this.createUserProgress(progress1);
    await this.createUserProgress(progress2);
    await this.createUserProgress(progress3);

    // Create sample market insights
    const insight1 = {
      title: "Lagos Retail Trends",
      description: "Recent shifts in consumer behavior in Lagos retail markets",
      category: "Retail",
      region: "Lagos",
      importance: "important" as "normal" | "important" | "urgent",
      keyTakeaway: "Focus on essential products and online presence",
      content: "# Lagos Retail Market Trends\n\n## Overview\n\nThe retail landscape in Lagos has seen significant changes in the past quarter...\n\n## Key Trends\n\n1. Increased demand for essential goods\n2. Growth in mobile shopping\n3. Price sensitivity due to inflation\n\n## Opportunities\n\n- Expansion into online retail channels\n- Bundle pricing strategies\n- Community-focused marketing\n\n## Challenges\n\n- Supply chain disruptions\n- Rising operational costs\n- Increased competition"
    };
    
    const insight2 = {
      title: "Funding Options for SMEs",
      description: "New funding opportunities for small businesses in Nigeria",
      category: "Finance",
      region: "National",
      importance: "normal" as "normal" | "important" | "urgent",
      keyTakeaway: "Explore microfinance and government grant programs",
      content: "# Funding Options for Nigerian SMEs\n\n## Overview\n\nAccess to capital remains a key challenge for many small businesses in Nigeria...\n\n## Available Funding Sources\n\n1. Microfinance institutions\n2. Government grant programs\n3. Angel investors and incubators\n\n## Application Strategies\n\n- Developing a solid business plan\n- Financial record keeping\n- Building banking relationships\n\n## Common Pitfalls\n\n- Incomplete documentation\n- Unrealistic projections\n- Poor financial management history"
    };
    
    await this.createMarketInsight(insight1);
    await this.createMarketInsight(insight2);

    // Create sample profile questions
    const question1 = {
      question: "What is your primary business challenge?",
      options: ["Finding customers", "Managing cash flow", "Hiring staff", "Supply chain issues", "Access to funding"],
      category: "General"
    };
    
    const question2 = {
      question: "How do you currently market your business?",
      options: ["Social media", "Word of mouth", "Traditional advertising", "Not currently marketing", "Other"],
      category: "Marketing"
    };
    
    const question3 = {
      question: "What is your target growth rate for this year?",
      options: ["0-10%", "11-25%", "26-50%", "51-100%", "Over 100%"],
      category: "Planning"
    };
    
    await this.createProfileQuestion(question1);
    await this.createProfileQuestion(question2);
    await this.createProfileQuestion(question3);

    console.log("Sample data initialization completed");
  }
}

// Export a singleton instance
export const pgStorage = new PgStorage();