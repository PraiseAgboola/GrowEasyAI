import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  businessName: text("business_name"),
  businessType: text("business_type"),
  location: text("location"),
  profileCreated: timestamp("profile_created").defaultNow(),
  lastActive: timestamp("last_active").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  profileCreated: true,
  lastActive: true,
});

// Learning Modules
export const learningModules = pgTable("learning_modules", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  duration: integer("duration").notNull(), // in minutes
  content: text("content").notNull(),
  imageUrl: text("image_url"),
});

export const insertLearningModuleSchema = createInsertSchema(learningModules).omit({
  id: true,
});

// User Learning Progress
export const userProgress = pgTable("user_progress", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  moduleId: integer("module_id").notNull(),
  progressPercentage: integer("progress_percentage").notNull().default(0),
  completed: boolean("completed").notNull().default(false),
  lastUpdated: timestamp("last_updated").defaultNow(),
});

export const insertUserProgressSchema = createInsertSchema(userProgress).omit({
  id: true,
  lastUpdated: true,
});

// Market Insights
export const marketInsights = pgTable("market_insights", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  category: text("category").notNull(),
  region: text("region").notNull(),
  importance: text("importance").notNull().default("normal"), // normal, important, urgent
  keyTakeaway: text("key_takeaway").notNull(),
  publishedDate: timestamp("published_date").defaultNow(),
  content: text("content").notNull(),
});

export const insertMarketInsightSchema = createInsertSchema(marketInsights).omit({
  id: true,
  publishedDate: true,
});

// Chat Conversations
export const chatConversations = pgTable("chat_conversations", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  startTime: timestamp("start_time").defaultNow(),
  lastMessageTime: timestamp("last_message_time").defaultNow(),
});

export const insertChatConversationSchema = createInsertSchema(chatConversations).omit({
  id: true,
  startTime: true,
  lastMessageTime: true,
});

// Chat Messages
export const chatMessages = pgTable("chat_messages", {
  id: serial("id").primaryKey(),
  conversationId: integer("conversation_id").notNull(),
  sender: text("sender").notNull(), // "user" or "ai"
  content: text("content").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertChatMessageSchema = createInsertSchema(chatMessages).omit({
  id: true,
  timestamp: true,
});

// User Profile Questions for Business Assessment
export const profileQuestions = pgTable("profile_questions", {
  id: serial("id").primaryKey(),
  question: text("question").notNull(),
  options: text("options").array().notNull(),
  category: text("category").notNull(),
});

export const insertProfileQuestionSchema = createInsertSchema(profileQuestions).omit({
  id: true,
});

// User Answers to Profile Questions
export const userAnswers = pgTable("user_answers", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  questionId: integer("question_id").notNull(),
  answer: text("answer").notNull(),
  timestamp: timestamp("timestamp").defaultNow(),
});

export const insertUserAnswerSchema = createInsertSchema(userAnswers).omit({
  id: true,
  timestamp: true,
});

// Offline Content Cache
export const offlineContent = pgTable("offline_content", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  contentType: text("content_type").notNull(), // "module", "insight", "tip"
  contentId: integer("content_id").notNull(),
  content: jsonb("content").notNull(),
  cachedAt: timestamp("cached_at").defaultNow(),
});

export const insertOfflineContentSchema = createInsertSchema(offlineContent).omit({
  id: true,
  cachedAt: true,
});

// Type exports for all schemas
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type LearningModule = typeof learningModules.$inferSelect;
export type InsertLearningModule = z.infer<typeof insertLearningModuleSchema>;

export type UserProgress = typeof userProgress.$inferSelect;
export type InsertUserProgress = z.infer<typeof insertUserProgressSchema>;

export type MarketInsight = typeof marketInsights.$inferSelect;
export type InsertMarketInsight = z.infer<typeof insertMarketInsightSchema>;

export type ChatConversation = typeof chatConversations.$inferSelect;
export type InsertChatConversation = z.infer<typeof insertChatConversationSchema>;

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = z.infer<typeof insertChatMessageSchema>;

export type ProfileQuestion = typeof profileQuestions.$inferSelect;
export type InsertProfileQuestion = z.infer<typeof insertProfileQuestionSchema>;

export type UserAnswer = typeof userAnswers.$inferSelect;
export type InsertUserAnswer = z.infer<typeof insertUserAnswerSchema>;

export type OfflineContent = typeof offlineContent.$inferSelect;
export type InsertOfflineContent = z.infer<typeof insertOfflineContentSchema>;
