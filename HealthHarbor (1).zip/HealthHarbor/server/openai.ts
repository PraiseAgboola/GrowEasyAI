import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const OPENAI_MODEL = "gpt-4o";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

const openai = new OpenAI({ 
  apiKey: OPENAI_API_KEY 
});

export async function generateAIResponse(userQuery: string): Promise<string> {
  try {
    // Format system prompt to guide AI responses
    const systemPrompt = `
      You are an AI mentor for Nigerian entrepreneurs, specializing in business advice, 
      market insights, and practical tips for small businesses in Nigeria. 
      Use a friendly, helpful tone and provide specific, actionable advice relevant to Nigerian business context.
      Consider local market conditions, regulations, and cultural factors in your responses.
      Keep answers concise but comprehensive, focusing on practical steps entrepreneurs can take.
      If you don't know something specific about Nigerian markets, be honest about limitations.
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userQuery }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content || "I'm not sure how to respond to that. Could you rephrase your question?";
  } catch (error) {
    console.error("OpenAI API error:", error);
    return "I'm having trouble connecting to my knowledge base. Please try again later.";
  }
}

export async function generateLearningRecommendations(
  businessType: string,
  userResponses: Record<string, string>
): Promise<string[]> {
  try {
    const prompt = `
      Based on the following information about a Nigerian entrepreneur:
      Business Type: ${businessType}
      ${Object.entries(userResponses).map(([q, a]) => `${q}: ${a}`).join('\n')}
      
      Recommend 3-5 learning modules that would be most beneficial.
      Return ONLY the module names as a JSON array of strings.
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return result.recommendations || ["Basic Business Management", "Financial Literacy", "Marketing Essentials"];
  } catch (error) {
    console.error("OpenAI recommendation error:", error);
    return ["Basic Business Management", "Financial Literacy", "Marketing Essentials"];
  }
}

export async function generateMarketInsight(
  region: string,
  industry: string
): Promise<{
  title: string;
  description: string;
  keyTakeaway: string;
  importance: "normal" | "important" | "urgent";
}> {
  try {
    const prompt = `
      Generate a market insight for a ${industry} business in ${region}, Nigeria.
      Return the response in JSON format with the following fields:
      - title: A concise title for the insight
      - description: A 1-2 sentence description of the insight
      - keyTakeaway: A specific action recommendation based on the insight
      - importance: Either "normal", "important", or "urgent" based on how critical this insight is
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      title: result.title || "Market Update",
      description: result.description || "Current market data is unavailable.",
      keyTakeaway: result.keyTakeaway || "Monitor market conditions closely.",
      importance: (result.importance as "normal" | "important" | "urgent") || "normal"
    };
  } catch (error) {
    console.error("OpenAI market insight error:", error);
    
    return {
      title: "Market Data Unavailable",
      description: "We're currently unable to generate market insights.",
      keyTakeaway: "Check back later for updated information.",
      importance: "normal"
    };
  }
}
