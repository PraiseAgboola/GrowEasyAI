import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { ZodError } from "zod";
import { 
  insertUserSchema, 
  insertLearningModuleSchema,
  insertUserProgressSchema,
  insertMarketInsightSchema,
  insertChatConversationSchema,
  insertChatMessageSchema,
  insertProfileQuestionSchema,
  insertUserAnswerSchema,
  insertOfflineContentSchema
} from "@shared/schema";
import { generateAIResponse } from "./openai";

export async function registerRoutes(app: Express): Promise<Server> {
  // Error handling middleware for Zod validation errors
  const handleZodError = (err: unknown, res: Response) => {
    if (err instanceof ZodError) {
      return res.status(400).json({
        message: "Validation error",
        errors: err.errors
      });
    }
    return res.status(500).json({ message: "Internal server error" });
  };

  // User routes
  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send the password in the response
      const { password, ...userWithoutPassword } = user;
      res.json(userWithoutPassword);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve user" });
    }
  });

  app.post("/api/users", async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(userData.username);
      
      if (existingUser) {
        return res.status(409).json({ message: "Username already exists" });
      }
      
      const newUser = await storage.createUser(userData);
      
      // Don't send the password in the response
      const { password, ...userWithoutPassword } = newUser;
      res.status(201).json(userWithoutPassword);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  app.patch("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.id);
      // Partial validation allows updating only some fields
      const userData = insertUserSchema.partial().parse(req.body);
      
      const updatedUser = await storage.updateUser(userId, userData);
      
      if (!updatedUser) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Don't send the password in the response
      const { password, ...userWithoutPassword } = updatedUser;
      res.json(userWithoutPassword);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Learning module routes
  app.get("/api/learning-modules", async (_req: Request, res: Response) => {
    try {
      const modules = await storage.getLearningModules();
      res.json(modules);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve learning modules" });
    }
  });

  app.get("/api/learning-modules/:id", async (req: Request, res: Response) => {
    try {
      const moduleId = parseInt(req.params.id);
      const module = await storage.getLearningModule(moduleId);
      
      if (!module) {
        return res.status(404).json({ message: "Learning module not found" });
      }
      
      res.json(module);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve learning module" });
    }
  });

  app.get("/api/learning-modules/category/:category", async (req: Request, res: Response) => {
    try {
      const category = req.params.category;
      const modules = await storage.getLearningModulesByCategory(category);
      res.json(modules);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve learning modules by category" });
    }
  });

  app.post("/api/learning-modules", async (req: Request, res: Response) => {
    try {
      const moduleData = insertLearningModuleSchema.parse(req.body);
      const newModule = await storage.createLearningModule(moduleData);
      res.status(201).json(newModule);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // User progress routes
  app.get("/api/users/:userId/progress", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const progress = await storage.getUserProgress(userId);
      res.json(progress);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve user progress" });
    }
  });

  app.get("/api/users/:userId/progress/:moduleId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const moduleId = parseInt(req.params.moduleId);
      const progress = await storage.getUserModuleProgress(userId, moduleId);
      
      if (!progress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      
      res.json(progress);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve user module progress" });
    }
  });

  app.post("/api/user-progress", async (req: Request, res: Response) => {
    try {
      const progressData = insertUserProgressSchema.parse(req.body);
      
      // Check if progress already exists
      const existingProgress = await storage.getUserModuleProgress(
        progressData.userId,
        progressData.moduleId
      );
      
      if (existingProgress) {
        // Update existing progress instead
        const updatedProgress = await storage.updateUserProgress(
          progressData.userId,
          progressData.moduleId,
          progressData
        );
        return res.json(updatedProgress);
      }
      
      // Create new progress
      const newProgress = await storage.createUserProgress(progressData);
      res.status(201).json(newProgress);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  app.patch("/api/user-progress/:userId/:moduleId", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const moduleId = parseInt(req.params.moduleId);
      
      // Partial validation allows updating only some fields
      const progressData = insertUserProgressSchema.partial().parse(req.body);
      
      const updatedProgress = await storage.updateUserProgress(userId, moduleId, progressData);
      
      if (!updatedProgress) {
        return res.status(404).json({ message: "Progress not found" });
      }
      
      res.json(updatedProgress);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Market insight routes
  app.get("/api/market-insights", async (_req: Request, res: Response) => {
    try {
      const insights = await storage.getMarketInsights();
      res.json(insights);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve market insights" });
    }
  });

  app.get("/api/market-insights/:id", async (req: Request, res: Response) => {
    try {
      const insightId = parseInt(req.params.id);
      const insight = await storage.getMarketInsight(insightId);
      
      if (!insight) {
        return res.status(404).json({ message: "Market insight not found" });
      }
      
      res.json(insight);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve market insight" });
    }
  });

  app.get("/api/market-insights/region/:region", async (req: Request, res: Response) => {
    try {
      const region = req.params.region;
      const insights = await storage.getMarketInsightsByRegion(region);
      res.json(insights);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve market insights by region" });
    }
  });

  app.post("/api/market-insights", async (req: Request, res: Response) => {
    try {
      const insightData = insertMarketInsightSchema.parse(req.body);
      const newInsight = await storage.createMarketInsight(insightData);
      res.status(201).json(newInsight);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Chat conversation routes
  app.get("/api/users/:userId/conversations", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const conversations = await storage.getChatConversations(userId);
      res.json(conversations);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve chat conversations" });
    }
  });

  app.post("/api/conversations", async (req: Request, res: Response) => {
    try {
      const conversationData = insertChatConversationSchema.parse(req.body);
      const newConversation = await storage.createChatConversation(conversationData);
      res.status(201).json(newConversation);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Chat message routes
  app.get("/api/conversations/:conversationId/messages", async (req: Request, res: Response) => {
    try {
      const conversationId = parseInt(req.params.conversationId);
      const messages = await storage.getChatMessages(conversationId);
      res.json(messages);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve chat messages" });
    }
  });

  app.post("/api/messages", async (req: Request, res: Response) => {
    try {
      const messageData = insertChatMessageSchema.parse(req.body);
      const newMessage = await storage.createChatMessage(messageData);
      res.status(201).json(newMessage);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // AI mentor routes
  app.post("/api/ai/chat", async (req: Request, res: Response) => {
    try {
      const { userId, message, conversationId } = req.body;
      
      if (!userId || !message) {
        return res.status(400).json({ message: "userId and message are required" });
      }
      
      // Create a new conversation if one doesn't exist
      let convoId = conversationId;
      if (!convoId) {
        const newConversation = await storage.createChatConversation({ userId });
        convoId = newConversation.id;
      }
      
      // Store the user message
      await storage.createChatMessage({
        conversationId: convoId,
        sender: "user",
        content: message
      });
      
      // Generate AI response
      const aiResponse = await generateAIResponse(message);
      
      // Store the AI message
      const aiMessage = await storage.createChatMessage({
        conversationId: convoId,
        sender: "ai",
        content: aiResponse
      });
      
      res.json({
        message: aiMessage,
        conversationId: convoId
      });
    } catch (err) {
      res.status(500).json({ message: "Failed to process AI chat request" });
    }
  });

  // Profile questions routes
  app.get("/api/profile-questions", async (_req: Request, res: Response) => {
    try {
      const questions = await storage.getProfileQuestions();
      res.json(questions);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve profile questions" });
    }
  });

  app.get("/api/profile-questions/category/:category", async (req: Request, res: Response) => {
    try {
      const category = req.params.category;
      const questions = await storage.getProfileQuestionsByCategory(category);
      res.json(questions);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve profile questions by category" });
    }
  });

  // User answers routes
  app.get("/api/users/:userId/answers", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const answers = await storage.getUserAnswers(userId);
      res.json(answers);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve user answers" });
    }
  });

  app.post("/api/user-answers", async (req: Request, res: Response) => {
    try {
      const answerData = insertUserAnswerSchema.parse(req.body);
      const newAnswer = await storage.createUserAnswer(answerData);
      res.status(201).json(newAnswer);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Offline content routes
  app.get("/api/users/:userId/offline-content", async (req: Request, res: Response) => {
    try {
      const userId = parseInt(req.params.userId);
      const content = await storage.getUserOfflineContent(userId);
      res.json(content);
    } catch (err) {
      res.status(500).json({ message: "Failed to retrieve offline content" });
    }
  });

  app.post("/api/offline-content", async (req: Request, res: Response) => {
    try {
      const contentData = insertOfflineContentSchema.parse(req.body);
      const newContent = await storage.createOfflineContent(contentData);
      res.status(201).json(newContent);
    } catch (err) {
      handleZodError(err, res);
    }
  });

  // Create the HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
