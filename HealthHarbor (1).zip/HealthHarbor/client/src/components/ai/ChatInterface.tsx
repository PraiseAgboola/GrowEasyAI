import { useState, useRef, useEffect } from "react";
import { useChat } from "@/contexts/ChatContext";
import { useUser } from "@/contexts/UserContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const ChatInterface = () => {
  const { messages, conversationId, isOpen, loading, openChat, closeChat, sendMessage } = useChat();
  const { user } = useUser();
  const [inputValue, setInputValue] = useState("");
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // Scroll to bottom when messages change
  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputValue.trim()) {
      sendMessage(inputValue);
      setInputValue("");
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-20">
      {isOpen ? (
        <div className="bg-white rounded-lg shadow-lg border border-neutral-border overflow-hidden" style={{ width: "350px", maxHeight: "500px" }}>
          <div className="p-3 bg-primary text-white flex justify-between items-center">
            <div className="flex items-center">
              <span className="material-icons mr-2">smart_toy</span>
              <h3 className="font-heading font-medium">AI Business Mentor</h3>
            </div>
            <button onClick={closeChat} className="text-white">
              <span className="material-icons">close</span>
            </button>
          </div>
          
          <div className="h-96 overflow-y-auto p-4 bg-neutral-light" id="chat-messages">
            {messages.map((message, index) => (
              <div key={message.id || index} className={`flex mb-4 ${message.sender === 'user' ? 'justify-end' : ''}`}>
                {message.sender === 'ai' && (
                  <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
                    <span className="material-icons text-sm">smart_toy</span>
                  </div>
                )}
                
                <div className={`ml-2 mr-2 chat-message ${message.sender === 'ai' ? 'bot-message' : 'user-message'} rounded-lg p-3 ${message.sender === 'user' ? 'mr-2' : 'ml-2'}`} style={{ maxWidth: '85%' }}>
                  <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                </div>
                
                {message.sender === 'user' && (
                  <div className="w-8 h-8 rounded-full bg-neutral-muted flex items-center justify-center text-white flex-shrink-0">
                    <span className="material-icons text-sm">person</span>
                  </div>
                )}
              </div>
            ))}
            {loading && (
              <div className="flex mb-4">
                <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center text-white flex-shrink-0">
                  <span className="material-icons text-sm">smart_toy</span>
                </div>
                <div className="ml-2 chat-message bot-message rounded-lg p-3" style={{ maxWidth: '85%' }}>
                  <p className="text-sm">Thinking...</p>
                </div>
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
          
          <div className="p-3 border-t border-neutral-border">
            <form onSubmit={handleSendMessage} className="flex">
              <Input
                type="text"
                placeholder="Ask a business question..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                className="flex-1 px-3 py-2 border border-neutral-border rounded-l-md focus:outline-none focus:border-primary"
                disabled={loading}
              />
              <Button 
                type="submit" 
                className="bg-primary text-white px-3 py-2 rounded-r-md" 
                disabled={loading || !inputValue.trim()}
              >
                <span className="material-icons">send</span>
              </Button>
            </form>
          </div>
        </div>
      ) : (
        <Button
          onClick={openChat}
          className="bg-primary text-white w-14 h-14 rounded-full shadow-lg flex items-center justify-center"
        >
          <span className="material-icons">chat</span>
        </Button>
      )}
    </div>
  );
};

export default ChatInterface;
