import { Link, useLocation } from "wouter";
import { useUser } from "@/contexts/UserContext";

const Sidebar = () => {
  const [location] = useLocation();
  const { user } = useUser();

  return (
    <div id="sidebar" className="hidden md:flex md:w-64 bg-white border-r border-neutral-border flex-col h-screen sticky top-0">
      <div className="p-4 border-b border-neutral-border flex items-center">
        <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center text-white mr-3">
          <span className="text-lg font-bold">G</span>
        </div>
        <h1 className="font-heading font-semibold text-lg">GrowEasyAI</h1>
      </div>
      
      <div className="flex-1 overflow-y-auto py-4 px-3">
        <nav>
          <Link href="/">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">home</span>
              <span>Dashboard</span>
            </a>
          </Link>
          
          <Link href="/learning">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/learning' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">school</span>
              <span>Learning</span>
            </a>
          </Link>
          
          <Link href="/market-insights">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/market-insights' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">show_chart</span>
              <span>Market Insights</span>
            </a>
          </Link>
          
          <Link href="/ai-mentor">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/ai-mentor' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">chat</span>
              <span>AI Mentor</span>
            </a>
          </Link>
          
          <Link href="/resources">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/resources' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">folder</span>
              <span>Resources</span>
            </a>
          </Link>
          
          <Link href="/settings">
            <a className={`flex items-center px-3 py-2 my-1 rounded-md ${location === '/settings' ? 'bg-primary text-white' : 'text-neutral hover:bg-neutral-light transition-colors'}`}>
              <span className="material-icons mr-3">settings</span>
              <span>Settings</span>
            </a>
          </Link>
        </nav>
      </div>
      
      <div className="p-4 border-t border-neutral-border">
        <div className="flex items-center">
          <div className="w-10 h-10 rounded-full bg-neutral-light flex items-center justify-center">
            <span className="material-icons">person</span>
          </div>
          <div className="ml-3">
            <p className="font-medium text-sm">{user?.firstName} {user?.lastName}</p>
            <p className="text-xs text-neutral-muted">{user?.businessName || 'Business not set'}</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Sidebar;
