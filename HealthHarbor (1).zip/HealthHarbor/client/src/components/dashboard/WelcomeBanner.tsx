import { useUser } from "@/contexts/UserContext";
import { useChat } from "@/contexts/ChatContext";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const WelcomeBanner = () => {
  const { user } = useUser();
  const { openChat } = useChat();

  return (
    <div className="bg-primary rounded-lg p-6 mb-6 text-white">
      <h2 className="font-heading text-2xl font-semibold mb-2">
        Welcome back, {user?.firstName || 'Entrepreneur'}!
      </h2>
      <p className="mb-4">Continue growing your business skills and stay updated with the latest market trends.</p>
      <div className="flex items-center flex-wrap gap-3">
        <Link href="/learning">
          <Button variant="secondary" className="bg-white text-primary hover:bg-neutral-100 font-medium">
            <span className="material-icons mr-2">play_arrow</span>
            Continue Learning
          </Button>
        </Link>
        <Button 
          variant="default" 
          className="bg-primary-dark hover:bg-primary-dark/90 text-white font-medium"
          onClick={openChat}
        >
          <span className="material-icons mr-2">chat</span>
          Ask AI Mentor
        </Button>
      </div>
    </div>
  );
};

export default WelcomeBanner;
