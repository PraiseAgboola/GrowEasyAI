import { LearningModule } from "@shared/schema";
import { Link } from "wouter";

interface CourseCardProps {
  module: LearningModule;
}

const CourseCard = ({ module }: CourseCardProps) => {
  return (
    <div className="bg-white rounded-lg shadow-sm border border-neutral-border overflow-hidden">
      <div className="h-36 bg-neutral-light relative">
        {module.imageUrl ? (
          <img 
            src={module.imageUrl} 
            alt={module.title} 
            className="w-full h-full object-cover" 
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-primary bg-opacity-10">
            <span className="material-icons text-4xl text-primary">school</span>
          </div>
        )}
        <span className="absolute top-3 right-3 bg-white text-neutral text-xs font-medium px-2 py-1 rounded-full">
          {module.duration} min
        </span>
      </div>
      <div className="p-4">
        <h4 className="font-heading font-semibold mb-1">{module.title}</h4>
        <p className="text-sm text-neutral-muted mb-3">{module.description}</p>
        <div className="flex justify-between items-center">
          <span className="flex items-center text-sm text-neutral-muted">
            <span className="material-icons text-sm mr-1">school</span>
            {module.category} Module
          </span>
          <Link href={`/learning/${module.id}`}>
            <a className="text-primary text-sm font-medium">Start</a>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default CourseCard;
