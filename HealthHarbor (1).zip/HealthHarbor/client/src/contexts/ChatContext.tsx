import React, { createContext, useContext, useState, useCallback } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface Message {
  id: number;
  conversationId: number;
  sender: "user" | "ai";
  content: string;
  timestamp: string;
}

interface ChatContextType {
  messages: Message[];
  conversationId: number | null;
  isOpen: boolean;
  loading: boolean;
  error: string | null;
  openChat: () => void;
  closeChat: () => void;
  sendMessage: (message: string) => Promise<void>;
  clearMessages: () => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [conversationId, setConversationId] = useState<number | null>(null);
  const [isOpen, setIsOpen] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const { toast } = useToast();

  const openChat = useCallback(() => {
    setIsOpen(true);
    
    // If we don't have any messages yet, add a welcome message
    if (messages.length === 0) {
      setMessages([{
        id: 0,
        conversationId: 0,
        sender: "ai",
        content: "Hello! I'm your AI Business Mentor. How can I help you today with your business?",
        timestamp: new Date().toISOString()
      }]);
    }
  }, [messages.length]);

  const closeChat = useCallback(() => {
    setIsOpen(false);
  }, []);

  const sendMessage = useCallback(async (content: string) => {
    if (!content.trim()) return;
    
    // Optimistically add user message to the UI
    const tempUserMessage = {
      id: Date.now(),
      conversationId: conversationId || 0,
      sender: "user" as const,
      content,
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, tempUserMessage]);
    setLoading(true);
    
    try {
      // Assuming we have a logged-in user with ID 1 for demo purposes
      const userId = 1;
      
      const response = await apiRequest("POST", "/api/ai/chat", {
        userId,
        message: content,
        conversationId
      });
      
      const data = await response.json();
      
      // Update conversation ID if this is a new conversation
      if (data.conversationId && !conversationId) {
        setConversationId(data.conversationId);
      }
      
      // Add AI response to message list
      setMessages(prev => [...prev, data.message]);
      setError(null);
    } catch (err: any) {
      console.error("Send message error:", err);
      setError(err.message || "Failed to send message");
      
      // Add a fallback AI message if the API call fails
      const fallbackMessage = {
        id: Date.now() + 1,
        conversationId: conversationId || 0,
        sender: "ai" as const,
        content: "I'm having trouble connecting to my knowledge base right now. Please try again later.",
        timestamp: new Date().toISOString()
      };
      
      setMessages(prev => [...prev, fallbackMessage]);
      
      toast({
        variant: "destructive",
        title: "Message failed",
        description: "There was a problem sending your message.",
      });
    } finally {
      setLoading(false);
    }
  }, [conversationId, toast]);

  const clearMessages = useCallback(() => {
    setMessages([]);
    setConversationId(null);
  }, []);

  return (
    <ChatContext.Provider
      value={{
        messages,
        conversationId,
        isOpen,
        loading,
        error,
        openChat,
        closeChat,
        sendMessage,
        clearMessages,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error("useChat must be used within a ChatProvider");
  }
  return context;
};
