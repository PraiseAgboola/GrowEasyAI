import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const OPENAI_MODEL = "gpt-4o";
const OPENAI_API_KEY = process.env.OPENAI_API_KEY || "";

const openai = new OpenAI({ 
  apiKey: OPENAI_API_KEY,
  dangerouslyAllowBrowser: true
});

export async function generateAIResponse(userQuery: string): Promise<string> {
  try {
    // Format system prompt to guide AI responses
    const systemPrompt = `
      You are an AI mentor for Nigerian entrepreneurs, specializing in business advice, 
      market insights, and practical tips for small businesses in Nigeria. 
      Use a friendly, helpful tone and provide specific, actionable advice relevant to Nigerian business context.
      Consider local market conditions, regulations, and cultural factors in your responses.
      Keep answers concise but comprehensive, focusing on practical steps entrepreneurs can take.
      If you don't know something specific about Nigerian markets, be honest about limitations.
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userQuery }
      ],
      temperature: 0.7,
      max_tokens: 500
    });

    return response.choices[0].message.content || "I'm not sure how to respond to that. Could you rephrase your question?";
  } catch (error) {
    console.error("OpenAI API error:", error);
    return "I'm having trouble connecting to my knowledge base. Please try again later.";
  }
}

export async function analyzeBusinessProfile(answers: Record<string, string>): Promise<{
  businessType: string;
  strengths: string[];
  weaknesses: string[];
  recommendedModules: string[];
}> {
  try {
    const prompt = `
      Analyze the following business profile for a Nigerian entrepreneur:
      ${Object.entries(answers).map(([question, answer]) => `${question}: ${answer}`).join('\n')}

      Based on this information, provide the following in JSON format:
      1. Likely business type/category
      2. Key business strengths (3 points)
      3. Potential weaknesses/areas for improvement (3 points)
      4. Recommended learning modules (3-5 suggestions)
      
      Return the response as a JSON object with the following structure:
      {
        "businessType": "string",
        "strengths": ["string", "string", "string"],
        "weaknesses": ["string", "string", "string"],
        "recommendedModules": ["string", "string", "string", "string", "string"]
      }
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      businessType: result.businessType || "General Business",
      strengths: result.strengths || ["Not enough information"],
      weaknesses: result.weaknesses || ["Not enough information"],
      recommendedModules: result.recommendedModules || ["Basic Business Management", "Financial Literacy", "Marketing Essentials"]
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Return fallback data if there's an error
    return {
      businessType: "Unknown",
      strengths: ["Not available due to analysis error"],
      weaknesses: ["Not available due to analysis error"],
      recommendedModules: ["Basic Business Management", "Financial Literacy", "Marketing Essentials"]
    };
  }
}

export async function generateMarketInsights(region: string, industry: string): Promise<{
  insights: string;
  trends: string[];
  opportunities: string[];
  risks: string[];
}> {
  try {
    const prompt = `
      Generate market insights for a ${industry} business in ${region}, Nigeria.
      Consider current economic conditions, industry trends, local market factors, and seasonal influences.
      
      Return the response as a JSON object with the following structure:
      {
        "insights": "A brief summary of key market conditions",
        "trends": ["trend 1", "trend 2", "trend 3"],
        "opportunities": ["opportunity 1", "opportunity 2", "opportunity 3"],
        "risks": ["risk 1", "risk 2", "risk 3"]
      }
    `;

    const response = await openai.chat.completions.create({
      model: OPENAI_MODEL,
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    
    return {
      insights: result.insights || "Market data currently unavailable",
      trends: result.trends || ["Data unavailable"],
      opportunities: result.opportunities || ["Data unavailable"],
      risks: result.risks || ["Data unavailable"]
    };
  } catch (error) {
    console.error("OpenAI API error:", error);
    
    // Return fallback data if there's an error
    return {
      insights: "Unable to generate market insights at this time",
      trends: ["Data retrieval error"],
      opportunities: ["Data retrieval error"],
      risks: ["Data retrieval error"]
    };
  }
}
