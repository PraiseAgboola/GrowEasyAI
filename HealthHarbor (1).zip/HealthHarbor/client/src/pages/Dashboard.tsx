import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useUser } from "@/contexts/UserContext";
import WelcomeBanner from "@/components/dashboard/WelcomeBanner";
import ProgressCard from "@/components/dashboard/ProgressCard";
import InsightCard from "@/components/dashboard/InsightCard";
import CourseCard from "@/components/dashboard/CourseCard";
import { LearningModule, UserProgress, MarketInsight } from "@shared/schema";

const Dashboard = () => {
  const { user } = useUser();

  // Fetch user progress data
  const { data: progressData, isLoading: progressLoading } = useQuery<UserProgress[]>({
    queryKey: user ? [`/api/users/${user.id}/progress`] : [null],
    enabled: !!user
  });

  // Fetch learning modules data
  const { data: modulesData, isLoading: modulesLoading } = useQuery<LearningModule[]>({
    queryKey: ['/api/learning-modules']
  });

  // Fetch market insights data
  const { data: insightsData, isLoading: insightsLoading } = useQuery<MarketInsight[]>({
    queryKey: ['/api/market-insights']
  });

  // Match progress data with module data
  const progressWithModules = progressData && modulesData
    ? progressData.map(progress => ({
        progress,
        module: modulesData.find(module => module.id === progress.moduleId)
      })).filter(item => item.module) // Filter out any items without a matching module
    : [];

  // Get recommended modules (modules that the user hasn't started)
  const recommendedModules = modulesData
    ? modulesData.filter(module => 
        !progressData?.some(progress => progress.moduleId === module.id)
      ).slice(0, 3) // Limit to 3 modules
    : [];

  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <WelcomeBanner />

      {/* Your Progress */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-heading text-lg font-semibold">Your Learning Progress</h3>
          <Link href="/learning">
            <a className="text-primary text-sm font-medium flex items-center">
              View All
              <span className="material-icons text-sm ml-1">arrow_forward</span>
            </a>
          </Link>
        </div>
        
        {progressLoading || modulesLoading ? (
          <div className="text-center py-4">Loading progress...</div>
        ) : progressWithModules.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {progressWithModules.slice(0, 3).map(({ progress, module }) => (
              module && <ProgressCard key={progress.id} progress={progress} module={module} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
            <p className="text-neutral-muted">You haven't started any learning modules yet.</p>
            <Link href="/learning">
              <a className="text-primary font-medium mt-2 inline-block">Explore Learning Modules</a>
            </Link>
          </div>
        )}
      </div>

      {/* Market Insights */}
      <div className="mb-6">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-heading text-lg font-semibold">Market Insights</h3>
          <Link href="/market-insights">
            <a className="text-primary text-sm font-medium flex items-center">
              View All
              <span className="material-icons text-sm ml-1">arrow_forward</span>
            </a>
          </Link>
        </div>
        
        {insightsLoading ? (
          <div className="text-center py-4">Loading insights...</div>
        ) : insightsData && insightsData.length > 0 ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            {insightsData.slice(0, 2).map(insight => (
              <InsightCard key={insight.id} insight={insight} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
            <p className="text-neutral-muted">No market insights available at the moment.</p>
            <Link href="/market-insights">
              <a className="text-primary font-medium mt-2 inline-block">Check Back Later</a>
            </Link>
          </div>
        )}
      </div>

      {/* Recommended Learning */}
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-heading text-lg font-semibold">Recommended For You</h3>
          <Link href="/learning">
            <a className="text-primary text-sm font-medium flex items-center">
              View All
              <span className="material-icons text-sm ml-1">arrow_forward</span>
            </a>
          </Link>
        </div>
        
        {modulesLoading ? (
          <div className="text-center py-4">Loading recommendations...</div>
        ) : recommendedModules.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recommendedModules.map(module => (
              <CourseCard key={module.id} module={module} />
            ))}
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-sm p-5 border border-neutral-border text-center">
            <p className="text-neutral-muted">We don't have any recommendations for you at the moment.</p>
            <Link href="/learning">
              <a className="text-primary font-medium mt-2 inline-block">Browse All Modules</a>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;
