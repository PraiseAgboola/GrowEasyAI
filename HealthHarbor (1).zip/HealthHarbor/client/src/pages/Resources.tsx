import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";

const resources = [
  {
    id: 1,
    title: "Business Templates",
    description: "Download essential business document templates for Nigerian businesses.",
    icon: "description",
    items: [
      { name: "Business Plan Template", type: "DOCX" },
      { name: "Invoice Template", type: "XLSX" },
      { name: "Cash Flow Forecast", type: "XLSX" },
      { name: "Employee Contract", type: "DOCX" },
      { name: "Marketing Plan", type: "DOCX" }
    ]
  },
  {
    id: 2,
    title: "Government Resources",
    description: "Official resources and information from Nigerian government agencies.",
    icon: "account_balance",
    items: [
      { name: "CAC Registration Guide", type: "PDF" },
      { name: "Tax Compliance Checklist", type: "PDF" },
      { name: "Small Business Grants", type: "Link" },
      { name: "Import/Export Regulations", type: "PDF" },
      { name: "NAFDAC Registration", type: "Link" }
    ]
  },
  {
    id: 3,
    title: "Business Calculators",
    description: "Interactive tools to help with business calculations and planning.",
    icon: "calculate",
    items: [
      { name: "Profit Margin Calculator", type: "Tool" },
      { name: "Loan Repayment Calculator", type: "Tool" },
      { name: "Break-even Analysis", type: "Tool" },
      { name: "Pricing Strategy Tool", type: "Tool" },
      { name: "Inventory Turnover Calculator", type: "Tool" }
    ]
  },
  {
    id: 4,
    title: "Offline Learning Content",
    description: "Download content for offline access during low connectivity.",
    icon: "cloud_download",
    items: [
      { name: "Financial Management Basics", type: "PDF" },
      { name: "Customer Service Guide", type: "PDF" },
      { name: "Digital Marketing for Small Business", type: "PDF" },
      { name: "Supply Chain Management", type: "PDF" },
      { name: "Inventory Control Methods", type: "PDF" }
    ]
  }
];

const Resources = () => {
  return (
    <div className="p-4 md:p-6 bg-neutral-light">
      <div className="mb-6">
        <h2 className="font-heading text-2xl font-semibold mb-2">Business Resources</h2>
        <p className="text-neutral-muted">
          Access tools, templates, and documents to help run your Nigerian business more effectively.
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {resources.map(resource => (
          <Card key={resource.id}>
            <CardHeader>
              <CardTitle className="flex items-center">
                <span className="material-icons mr-2 text-primary">{resource.icon}</span>
                {resource.title}
              </CardTitle>
              <CardDescription>{resource.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {resource.items.map((item, index) => (
                  <li key={index} className="flex items-center justify-between p-2 rounded-md hover:bg-neutral-light">
                    <div className="flex items-center">
                      <span className="material-icons text-sm mr-2 text-neutral-muted">
                        {item.type === "PDF" ? "picture_as_pdf" :
                         item.type === "DOCX" ? "description" :
                         item.type === "XLSX" ? "table_chart" :
                         item.type === "Link" ? "link" : "calculate"}
                      </span>
                      <span>{item.name}</span>
                    </div>
                    <Button variant="outline" size="sm" className="flex items-center">
                      <span className="material-icons text-sm mr-1">
                        {item.type === "Tool" ? "open_in_new" : "download"}
                      </span>
                      {item.type === "Tool" ? "Use" : "Download"}
                    </Button>
                  </li>
                ))}
              </ul>
            </CardContent>
            <CardFooter>
              <Button className="w-full bg-primary hover:bg-primary-dark">
                View All {resource.title}
              </Button>
            </CardFooter>
          </Card>
        ))}
      </div>
      
      <div className="mt-8 bg-white rounded-lg shadow-sm p-6 border border-neutral-border">
        <div className="text-center mb-4">
          <h3 className="font-heading text-xl font-semibold">Need Help Finding Resources?</h3>
          <p className="text-neutral-muted mt-1">Our AI Mentor can recommend specific resources based on your business needs.</p>
        </div>
        <div className="flex justify-center">
          <Link href="/ai-mentor">
            <Button className="bg-primary hover:bg-primary-dark mr-2">
              <span className="material-icons mr-2">smart_toy</span>
              Ask AI Mentor
            </Button>
          </Link>
          <Button variant="outline">
            <span className="material-icons mr-2">search</span>
            Search Resources
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Resources;
