# GrowEasyAI Deployment Instructions for Render

## Important: Docker Deployment Method (Most Reliable)

We've configured your application to use Docker for deployment, which solves many common deployment issues:

1. **Log in to your Render dashboard**
2. **Create a new Web Service**:
   - Click "New" → "Web Service" 
   - Choose either "Deploy from file upload" or "Connect GitHub repository"
3. **Configure Web Service Settings**:
   - **Name**: groweasyai
   - **Environment**: Docker
   - Render will automatically detect the Dockerfile

For manual configuration:
   - Dockerfile path: `./Dockerfile`
   - Docker Command: `node dist/index.js`
5. **Add Environment Variables**:
   - `NODE_ENV`: `production`
   - `OPENAI_API_KEY`: Your OpenAI API key
6. **Create and Connect PostgreSQL Database**:
   - Click "New" → "PostgreSQL"
   - Name: groweasyai-db
   - Copy the Internal Connection String
   - Go back to your Web Service → Environment
   - Add `DATABASE_URL` environment variable with the connection string
7. **Deploy your web service**
8. **Run Migrations**: 
   - Once deployed, go to Web Service "Shell" tab
   - Run: `npm run db:push`

## Alternative: GitHub Repository Method

If you prefer to deploy from a GitHub repository:

1. **Create a GitHub repository**:
   - Make sure package.json is at the root level
   - Push your code to GitHub
2. **Create a new Web Service**:
   - Click "New" → "Web Service"
   - Choose "Connect GitHub repository"
3. **Select your repository**
4. **Configure Web Service Settings**:
   - **Root Directory**: Leave empty (/)
   - **Build Command**: `ls -la && npm install && npm run build`
   - **Start Command**: `NODE_ENV=production node dist/index.js`
5. **Add Environment Variables** (same as above)
6. **Create and Connect Database** (same as above)
7. **Deploy and Run Migrations** (same as above)

## Debugging Deployment Issues

If you still encounter issues:

1. **Check build logs** in the Render dashboard
2. **Verify file structure**:
   - package.json must be at the root of your project
   - All dependencies must be listed in package.json
3. **Check environment variables**:
   - Make sure DATABASE_URL and OPENAI_API_KEY are set correctly
4. **Try manual shell commands**:
   - Use Render's Shell feature to run commands directly on the server
   - Run `ls -la` to see the file structure
   - Run `cat package.json` to verify the file exists and is correct

## Verify Deployment

- Visit your web service URL to make sure it's running correctly
- Test the key features of your application