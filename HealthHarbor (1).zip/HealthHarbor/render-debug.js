// This file helps debug deployment issues on Render
const fs = require('fs');
const path = require('path');
const child_process = require('child_process');

console.log('=== RENDER DEPLOYMENT DEBUGGER ===');
console.log(`Current working directory: ${process.cwd()}`);
console.log(`Node version: ${process.version}`);
console.log(`Process environment: ${process.env.NODE_ENV}`);

// Check directory structure
console.log('\n=== DIRECTORY STRUCTURE ===');
try {
  const files = fs.readdirSync(process.cwd());
  console.log('Files in current directory:');
  files.forEach(file => {
    const stats = fs.statSync(path.join(process.cwd(), file));
    console.log(`- ${file} (${stats.isDirectory() ? 'directory' : 'file'})`);
  });
} catch (error) {
  console.error(`Error reading directory: ${error.message}`);
}

// Check package.json
console.log('\n=== PACKAGE.JSON CHECK ===');
try {
  const packageJsonPath = path.join(process.cwd(), 'package.json');
  if (fs.existsSync(packageJsonPath)) {
    console.log('package.json exists!');
    try {
      const packageJson = require(packageJsonPath);
      console.log(`Name: ${packageJson.name}`);
      console.log(`Main: ${packageJson.main}`);
      console.log(`Scripts:`);
      Object.entries(packageJson.scripts || {}).forEach(([name, script]) => {
        console.log(`  - ${name}: ${script}`);
      });
    } catch (e) {
      console.error(`Error parsing package.json: ${e.message}`);
    }
  } else {
    console.error('package.json does not exist in the current directory');
    
    // Try to find package.json in parent directories
    let currentDir = process.cwd();
    let found = false;
    for (let i = 0; i < 5; i++) { // Check up to 5 levels up
      currentDir = path.dirname(currentDir);
      const testPath = path.join(currentDir, 'package.json');
      if (fs.existsSync(testPath)) {
        console.log(`Found package.json in parent directory: ${currentDir}`);
        found = true;
        break;
      }
    }
    
    if (!found) {
      console.log('package.json not found in any parent directory');
    }
  }
} catch (error) {
  console.error(`Error checking package.json: ${error.message}`);
}

// Check environment variables (without revealing values)
console.log('\n=== ENVIRONMENT VARIABLES ===');
try {
  const envVars = [
    'NODE_ENV',
    'DATABASE_URL',
    'OPENAI_API_KEY',
    'PORT'
  ];
  
  envVars.forEach(envVar => {
    if (process.env[envVar]) {
      console.log(`${envVar}: [PRESENT]`);
    } else {
      console.log(`${envVar}: [MISSING]`);
    }
  });
} catch (error) {
  console.error(`Error checking environment variables: ${error.message}`);
}

// Exit with success
console.log('\n=== DEBUG COMPLETE ===');